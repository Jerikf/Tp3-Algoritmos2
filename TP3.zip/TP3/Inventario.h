#ifndef INVENTARIO_H_INCLUDED
#define INVENTARIO_H_INCLUDED
#include "Material.h"
#include "Vect.h"

class Inventario{

    private:

    Vect<Material> *materiales;

    public:

    // PRE: -
    // POST: Inicializa el inventario.
    Inventario();

    // PRE: -
    // POST: Crea e inicializa un vector dinamico de materiales.
    void crear_materiales();


    // PRE: -
    // POST: Devuelve todos los materiales.
    Vect<Material>* devolver_materiales();
};

#endif //INVENTARIO_H_INCLUDED