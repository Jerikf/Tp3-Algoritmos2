#include "Juego.h"

int main(){

    Juego juego;

    juego.obtener_datos();
    juego.inicializar_juego();
    

    return 0;

}