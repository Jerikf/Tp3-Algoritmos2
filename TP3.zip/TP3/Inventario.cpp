#include "Inventario.h"
#include "constantes.h"

using namespace std;

Inventario::Inventario(){

    materiales = nullptr;

    crear_materiales();
}

void Inventario::crear_materiales(){

    materiales = new Vect<Material>[1];
}


Vect<Material>* Inventario::devolver_materiales(){

    return materiales;
}

