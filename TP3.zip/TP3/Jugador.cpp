#include "Jugador.h"

Jugador::Jugador(){

    crear_diccionario();
    cantidad_claves = 0;
    crear_vector_claves();

}

void Jugador::obtener_inventario(Inventario invnetario){
    
    limpiar_inventario();
    this-> inventario = invnetario;
}

Inventario Jugador::devolver_inventario(){

    return inventario;
}

void Jugador::limpiar_inventario(){

    delete[] inventario.devolver_materiales();

}

void Jugador::crear_diccionario(){

    edificios = new Diccionario<Edificio>(); 
}

void Jugador::crear_vector_claves(){

    claves_edificios = new string[cantidad_claves + 1];
}

string Jugador::devolver_clave_edificio(int posicion){

    return claves_edificios[posicion];
}

int Jugador::devolver_cant_edificios(){

    return cantidad_claves;
}

void Jugador::obtener_edificios(Diccionario<Edificio>* edificios){
    
    this-> edificios = edificios;
}

Diccionario<Edificio>* Jugador::devolver_edificios(){

    return edificios;
}

void Jugador::agregar_clave(string clave){

    claves_edificios[cantidad_claves] = clave;
    cantidad_claves ++;

    string* nuevo_vector = new string[cantidad_claves];

    for(int i = 0; i < cantidad_claves; i++){
        nuevo_vector[i] = claves_edificios[i];
    }

    delete[] claves_edificios;

    claves_edificios = new string[cantidad_claves + 1];


    for(int i = 0; i < cantidad_claves; i++){
        claves_edificios[i] = nuevo_vector[i];
    }

    delete[] nuevo_vector;

}

