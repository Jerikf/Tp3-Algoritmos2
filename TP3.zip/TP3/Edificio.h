#ifndef EDIFICIO_H_INCLUDED
#define EDIFICIO_H_INCLUDED
#include <string>

const int CANT_MAX_MATERIALES = 3;

class Edificio{

    protected:

    std::string nombre_edificio;
    int cant_piedra;
    int cant_madera;
    int cant_metal;
    int cant_maxima_edificios;
    char representacion;

    public:

    // PRE: -
    // POST: Inicializa el edificio.
    Edificio();

    // PRE: -
    // POST: Obtiene un edificio.
    void obtener_edificio(std::string nombre_edificio, int cant_piedra, int madera_, int cant_metal, int cant_maxima_edificios);

    // PRE: -
    // POST: Devuelve el nombhre del edificio.
    std::string devolver_nombre_edificio();

    // PRE: -
    // POST: Devuelve la cantidad maxima de edificios.
    int devolver_cant_maxima_edificios();

    // PRE: -
    // POST: Devuelve la cantidad de piedra del edificio.
    int devolver_cant_piedra();

    // PRE: -
    // POST: Devuelve la cantidad de madera del edificio.
    int devolver_cant_madera();

    // PRE: -
    // POST: Devuelve la cantiad de metal del edificio.
    int devolver_cant_metal();

    // PRE: -
    // POST: Muestra el nombre del edificio.
    void mostrar();

};

#endif // EDIFICIO_H_INCLUDED