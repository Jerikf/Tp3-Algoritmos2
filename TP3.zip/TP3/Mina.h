#ifndef MINA_H_INCLUDED
#define MINA_H_INCLUDED
#include "Edificio.h"

class Mina: public Edificio{



};

#endif //MINA_H_INCLUDED

