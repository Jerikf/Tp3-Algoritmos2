#ifndef JUGADOR_H_INCLUDED
#define JUGADOR_H_INCLUDED
#include "Inventario.h"
#include "Edificio.h"
#include "Diccionario.h"

class Jugador{

    private:

    Inventario inventario;
    Diccionario<Edificio>* edificios;
    std::string *claves_edificios;
    int cantidad_claves;

    public:
    
    // PRE: -
    // POST: Inicializa el jugador.
    Jugador();

    // PRE: EL invnetario esta bien cargado.
    // POST: Se obtiene el inventario del jugador.
    void obtener_inventario(Inventario inventario);
    
    // PRE: -
    // POST: Devuelve el inventario del jugador.
    Inventario devolver_inventario();
    
    // PRE: -
    // POST: Limpia la memoria dinamica de los materiales dependindo del inventario del juagador.
    void limpiar_inventario();

    // PRE: -
    // POST: Crea el diccionario.
    void crear_diccionario();
    
    // PRE: El diccionario es valido.
    // POST: Se obtiene le diccionario de edificios.
    void obtener_edificios(Diccionario<Edificio> *edificios);

    // PRE: -
    // POST: Devuelve el diccionario de edificios.
    Diccionario<Edificio>* devolver_edificios();

    // PRE: -
    // POST: Crea un vector dinamico con las claves de los edificios.
    void crear_vector_claves();
    
    // PRE: -
    // POST: Agrega una clave al vector de claves.
    void agregar_clave(std::string clave);


    // PRE: -
    // POST: Devuelve la clave del edificio por posicion.
    std::string devolver_clave_edificio(int posicion);

    // PRE: -
    // POST: Devuelve la cantidad de edificios.
    int devolver_cant_edificios();





};

#endif // JUGADOR_H_INCLUDED