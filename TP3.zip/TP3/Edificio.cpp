#include "Edificio.h"
#include "constantes.h"
#include <iostream>
using namespace std;

Edificio::Edificio(){

    nombre_edificio = VACIO;
    cant_piedra = 0;
    cant_madera = 0;
    cant_metal = 0;
    cant_maxima_edificios = NULO;
}

void Edificio::obtener_edificio(string nombre_edificio, int cant_piedra, int cant_madera, int cant_metal, int cant_maxima_edificios){
    
    this-> nombre_edificio = nombre_edificio;
    this-> cant_piedra = cant_piedra;
    this-> cant_madera = cant_madera;
    this-> cant_metal = cant_metal;
    this-> cant_maxima_edificios = cant_maxima_edificios;
}

string Edificio::devolver_nombre_edificio(){

    return nombre_edificio;
}


int Edificio::devolver_cant_maxima_edificios(){

    return cant_maxima_edificios;
}

int Edificio::devolver_cant_piedra(){

    return cant_piedra;
}

int Edificio::devolver_cant_madera(){

    return cant_madera;
}

int Edificio::devolver_cant_metal(){

    return cant_metal;
}

void Edificio::mostrar(){
    
    cout << "Nombre: " << nombre_edificio << endl;
    cout << "Materiales: " << endl;
    cout << "Piedra: " << cant_piedra << endl;
    cout << "Madera: " << cant_madera << endl;
    cout << "Metal: " << cant_metal << endl;
    cout << endl;
}