#ifndef ESCUELA_H_INCLUDED
#define ESCUELA_H_INCLUDED
#include "Edificio.h"

class Escuela: public Edificio{



}:

#endif // ESCUELA_H_INLUDED